/*
====================================================================
Please compile and run using a C++17 or higher compiler.
Compile command: g++ -std=c++17 -o test test.cpp
====================================================================
*/

#include "HeapSort.h"

// measureExecutionTime���ڲ������⺯����ִ��ʱ��
template <typename Func, typename... Args>
void measureExecutionTime(const std::string &func_name, Func &&func, Args &&...args)
{
    auto start = high_resolution_clock::now();

    // ���ô���ĺ��� func�������ݿɱ���� args��
    // std::invoke ����ͨ�õص��ú�����ɵ��ö��󣬽�� std::forward ���ֲ���������ת����
    std::invoke(std::forward<Func>(func), std::forward<Args>(args)...);

    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    cout << "Function \"" << func_name << "\" took " << duration.count() << " milliseconds." << endl;
}

// invokeFunc���ں������úͱ�ݸ�ʽ�������
template <typename Func, typename... Args>
void invokeFunc(const std::string &func_name, Func &&func, Args &&...args)
{
    cout << "========== Function \"" << func_name << "\" starts working ==========" << endl;
    std::invoke(std::forward<Func>(func), std::forward<Args>(args)...);
    cout << "========== Function \"" << func_name << "\" ends working =========\n\n\n";
}

// ���������
int myrand(int MOD) { return rand() * rand() % MOD; }

// ����������
void myHeapSort(vector<int> a) { heapsort(a); }
void stdHeapSort(vector<int> a)
{
    std::make_heap(a.begin(), a.end());
    std::sort_heap(a.begin(), a.end());
}

// inline void print(vector<int> a)
// {
//     for (int &num : a)
//         printf("%d ", num);
//     cout << endl;
//     heapsort(a);
//     for (int &num : a)
//         printf("%d ", num);
//     cout << endl;
// }

inline void sort(vector<int> a)
{
    // print(a);
    measureExecutionTime("my heapsort time", myHeapSort, a);
    measureExecutionTime("std::heapsort time", stdHeapSort, a);
}

// �������е����ɺ����庯������
inline void randomSequenceCheck(const int &N)
{
    std::vector<int> a(N, 0);
    for (int i = 0; i < N; i++)
    {
        int index = myrand(N);
        while (a[index] != 0)
            index = (index + 1) % N;
        a[index] = i + 1;
    }
    sort(a);
}
inline void orderedSequenceCheck(const int &N)
{
    std::vector<int> a(N, 0);
    for (int i = 0; i < N; i++)
        a[i] = i + 1;
    sort(a);
}
inline void reverseSequenceCheck(const int &N)
{
    std::vector<int> a(N, 0);
    for (int i = 0; i < N; i++)
        a[i] = N - i;
    sort(a);
}
inline void repetitiveSequenceCheck(const int &N)
{
    std::vector<int> a(N, 0);
    for (int i = 0; i < N; i++)
        a[i] = myrand(N);
    sort(a);
}

int main()
{
    srand(time(NULL));

    // ���г���
    const int N = 1000000;
    invokeFunc("random sequence", randomSequenceCheck, N);
    invokeFunc("ordered sequence", orderedSequenceCheck, N);
    invokeFunc("reverse sequence", reverseSequenceCheck, N);
    invokeFunc("repetitive sequence", repetitiveSequenceCheck, N);

    return 0;
}